---- #########################################################################
---- # Bind tool UI for black & white radios                                 #
---- #########################################################################

local deps = ...

local App = deps.App
local crsf = deps.crsf
local msp = deps.msp
local VERSION = deps.VERSION

local TextEdit = loadScript("/SCRIPTS/ELRS/ui/lcd/text_edit.lua")()
local Dialogs = loadScript("/SCRIPTS/ELRS/ui/lcd/dialogs.lua")()

-- Numeric ids save RAM; history rows are HIST_BASE + i
local ROW_PHRASE = 1
local ROW_TARGET = 2
local ROW_UID = 3
local ROW_SET = 4
local ROW_BIND = 5 -- Bind or Unbind, by link state
local ROW_HISTORY = 6
local ROW_EXIT = 7
local ROW_CLEAR = 8
local ROW_BACK = 9
local HIST_BASE = 100

local EXIT_LABEL = "[-- EXIT (" .. VERSION .. ") --]"

local PAGE_MAIN = 1
local PAGE_HISTORY = 2

-- Short forms: "Transmitter" would truncate at COL2 on 128 px
local TARGET_NAMES = { "TX", "RX", "Both" }

local UI = {
  page = PAGE_MAIN,
  lineIndex = 1,
  rows = {},
  editTarget = nil,
  ---@type table constructed in init(), needs LCD_W for the window
  phraseEdit = nil,

  -- { msg, i = history index, or nil to clear all }
  confirm = nil,

  -- 128x64; init widens COL2 on 212 px
  COL1 = 0,
  COL2 = 70,
  textSize = 8,
  textYoffset = 3,

  forceRedraw = true,
  lastStatus = nil,
}

-- Both pages fit 8 rows on 128x64: no scrolling

function UI.init()
  if LCD_W == 212 then
    UI.COL2 = 110
  end

  -- 6 px per char of the fixed BW font
  UI.phraseEdit = TextEdit.new(msp.CONST.PHRASE_MAX, math.floor((LCD_W - UI.COL2 - 2) / 6))
  UI.phraseEdit.value = App.phrase
end

function UI.preCheck(event)
  if not deps.versionOk then
    Dialogs.drawVersionRequired(deps.requiredVersions)
    if event == EVT_VIRTUAL_EXIT then
      App.shouldExit = true
      return 2
    end
    return 0
  end
  if not App.checkCrsfModule() then
    Dialogs.drawNoModule()
    return 0
  end
  return nil
end

local function buildRows()
  local rows = UI.rows
  for i = #rows, 1, -1 do
    rows[i] = nil
  end
  if UI.page == PAGE_MAIN then
    rows[1] = ROW_PHRASE
    rows[2] = ROW_TARGET
    rows[3] = ROW_UID
    rows[4] = ROW_SET
    if App.target == App.TARGET_RX then
      rows[5] = ROW_BIND
    end
    rows[#rows + 1] = ROW_HISTORY
    rows[#rows + 1] = ROW_EXIT
  else
    for i = 1, #App.history.items do
      rows[#rows + 1] = HIST_BASE + i
    end
    rows[#rows + 1] = ROW_CLEAR
    rows[#rows + 1] = ROW_BACK
  end
  if UI.lineIndex > #rows then
    UI.lineIndex = #rows
  end
end

-- Compact to fit 128 px at SMLSIZE
local function statusLine()
  if App.statusText then
    return App.statusText
  end
  local u = App.uid
  local prefix = (App.uidFrom == crsf.CONST.ADDRESS_RX) and "RX" or "TX"
  return string.format("%s: %d,%d,%d,%d,%d,%d", prefix, u[1], u[2], u[3], u[4], u[5], u[6])
end

local function selectRow(step)
  local count = #UI.rows
  local idx = UI.lineIndex + step
  if idx < 1 then
    idx = count
  elseif idx > count then
    idx = 1
  end
  UI.lineIndex = idx
end

local function goToPage(page)
  UI.page = page
  UI.lineIndex = 1
  UI.forceRedraw = true
end

local function handleEnter(id)
  if id == ROW_PHRASE then
    if App.isTargetReachableOrBoth() then
      UI.phraseEdit.value = App.phrase
      UI.phraseEdit:start()
    end
  elseif id == ROW_TARGET then
    UI.editTarget = true
  elseif id == ROW_UID then
    App.startUidRequest()
  elseif id == ROW_SET then
    if App.isTargetReachableOrBoth() and App.phrase ~= "" then
      App.sendSet()
    end
  elseif id == ROW_BIND then
    if crsf.hasTelemetry then
      App.sendUnbind()
    else
      App.sendBind()
    end
  elseif id == ROW_HISTORY then
    goToPage(PAGE_HISTORY)
  elseif id == ROW_EXIT then
    App.shouldExit = true
  elseif id == ROW_CLEAR then
    UI.confirm = { msg = "Clear history?" }
  elseif id == ROW_BACK then
    goToPage(PAGE_MAIN)
  elseif id > HIST_BASE then
    App.useHistory(id - HIST_BASE)
    UI.phraseEdit.value = App.phrase
    goToPage(PAGE_MAIN)
  end
end

local function handleEvent(event)
  if UI.phraseEdit.editing then
    if UI.phraseEdit:handleEvent(event) then
      App.phrase = UI.phraseEdit.value
    end
    return
  end

  if UI.editTarget then
    if event == EVT_VIRTUAL_NEXT then
      App.target = math.min(App.target + 1, App.TARGET_BOTH)
    elseif event == EVT_VIRTUAL_PREV then
      App.target = math.max(App.target - 1, App.TARGET_TX)
    elseif event == EVT_VIRTUAL_ENTER or event == EVT_VIRTUAL_EXIT then
      UI.editTarget = nil
    end
    return
  end

  if event == EVT_VIRTUAL_EXIT then
    if UI.page == PAGE_HISTORY then
      goToPage(PAGE_MAIN)
    else
      App.shouldExit = true
    end
  elseif event == EVT_VIRTUAL_ENTER then
    handleEnter(UI.rows[UI.lineIndex])
  elseif event == EVT_VIRTUAL_ENTER_LONG then
    killEvents(event)
    local id = UI.rows[UI.lineIndex]
    if id and id > HIST_BASE then
      UI.confirm = { msg = "Delete entry?", i = id - HIST_BASE }
    end
  elseif event == EVT_VIRTUAL_NEXT then
    selectRow(1)
  elseif event == EVT_VIRTUAL_PREV then
    selectRow(-1)
  end
end

local function drawTitle()
  lcd.drawFilledRectangle(0, 0, LCD_W, UI.textSize + 1, GREY_DEFAULT)
  lcd.drawText(UI.COL1 + 1, 1, "ExpressLRS Bind Tool", INVERS)
  -- C while RX telemetry is alive
  lcd.drawText(LCD_W - 1, 1, crsf.hasTelemetry and "C" or "-", INVERS + RIGHT)
end

local function drawRow(id, yPos, isSelected)
  local attr = isSelected and INVERS or 0
  if id == ROW_PHRASE then
    lcd.drawText(UI.COL1, yPos, "Phrase", 0)
    UI.phraseEdit:draw(UI.COL2, yPos, attr)
  elseif id == ROW_TARGET then
    if UI.editTarget and isSelected then
      attr = attr + BLINK
    end
    lcd.drawText(UI.COL1, yPos, "Target", 0)
    lcd.drawText(UI.COL2, yPos, TARGET_NAMES[App.target], attr)
  elseif id == ROW_UID then
    lcd.drawText(UI.COL1, yPos, statusLine(), attr + SMLSIZE)
  elseif id == ROW_SET then
    lcd.drawText(10, yPos, "[Set]", attr + BOLD)
  elseif id == ROW_BIND then
    lcd.drawText(10, yPos, crsf.hasTelemetry and "[Unbind]" or "[Bind]", attr + BOLD)
  elseif id == ROW_HISTORY then
    lcd.drawText(UI.COL1, yPos, "> History", attr + BOLD)
  elseif id == ROW_EXIT then
    lcd.drawText(10, yPos, EXIT_LABEL, attr + BOLD)
  elseif id == ROW_CLEAR then
    lcd.drawText(10, yPos, "[Clear All]", attr + BOLD)
  elseif id == ROW_BACK then
    lcd.drawText(10, yPos, "[---- BACK ----]", attr + BOLD)
  elseif id > HIST_BASE then
    lcd.drawText(UI.COL1, yPos, App.history.items[id - HIST_BASE] or "", attr)
  end
end

local function drawPage(event)
  handleEvent(event)
  buildRows()

  lcd.clear()
  drawTitle()

  -- No scrolling: each page is at most 7 rows
  for i = 1, #UI.rows do
    drawRow(UI.rows[i], i * UI.textSize + UI.textYoffset, UI.lineIndex == i)
  end
end

function UI.render(event, _touchState)
  -- Arm after a quiet frame, or the long press's ENTER release answers it
  if UI.confirm then
    local result = popupConfirmation(UI.confirm.msg, "PRESS [OK] to confirm", event)
    if not UI.confirm.armed then
      if event == 0 then
        UI.confirm.armed = true
      end
      return
    end
    if result == "OK" then
      if UI.confirm.i then
        App.removeHistory(UI.confirm.i)
      else
        App.clearHistory()
      end
      UI.confirm = nil
      UI.forceRedraw = true
    elseif result == "CANCEL" then
      UI.confirm = nil
      UI.forceRedraw = true
    end
    return
  end

  local status = statusLine() .. (crsf.hasTelemetry and "C" or "-")
  if event ~= 0 or UI.forceRedraw or UI.phraseEdit.editing or status ~= UI.lastStatus then
    drawPage(event)
    UI.lastStatus = status
    UI.forceRedraw = false
  end
end

return UI
