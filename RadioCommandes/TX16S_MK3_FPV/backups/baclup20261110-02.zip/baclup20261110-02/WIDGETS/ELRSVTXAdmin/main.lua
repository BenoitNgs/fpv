---------------------------------------------------------------------------
-- VTX Administrator Widget                                              --
-- Requires /SCRIPTS/ELRS on the SD card.                                --
---------------------------------------------------------------------------

local name = "ELRSVTXAdmin"

-- selene: allow(undefined_variable)
local function create(zone, options)
  if not _crsfSingleton then
    local getCRSF = loadScript("/SCRIPTS/ELRS/crsf.lua")
    ---@diagnostic disable-next-line: need-check-nil
    _crsfSingleton = getCRSF()
  end
  if not _crsfSessionClass then
    local getParams = loadScript("/SCRIPTS/ELRS/crsf_params.lua")
    ---@diagnostic disable-next-line: need-check-nil
    local params = getParams(_crsfSingleton)
    local getSessionClass = loadScript("/SCRIPTS/ELRS/crsf_session.lua")
    ---@diagnostic disable-next-line: need-check-nil
    _crsfSessionClass = getSessionClass(_crsfSingleton, params)
  end
  if not _vtxPresetsStorage then
    local getFileStorage = loadScript("/SCRIPTS/ELRS/file_storage.lua")
    ---@diagnostic disable-next-line: need-check-nil
    local fileStorage = getFileStorage()
    local getPresetsStorage = loadScript("/SCRIPTS/ELRS/vtx/presets.lua")
    ---@diagnostic disable-next-line: need-check-nil
    _vtxPresetsStorage = getPresetsStorage(fileStorage)
  end
  local loadable = loadScript("/WIDGETS/" .. name .. "/loadable.lua")
  ---@diagnostic disable-next-line: need-check-nil
  return loadable(zone, options, _crsfSingleton, _crsfSessionClass, _vtxPresetsStorage)
end

local function refresh(widget, event, touchState)
  widget.refresh(event, touchState)
end

local function background(widget)
  widget.background()
end

local function update(widget, options)
  widget.update(options)
end

return {
  name = "ExpressLRS VTX Admin",
  create = create,
  refresh = refresh,
  background = background,
  update = update,
  options = {
    { "Transparency", VALUE, 2, 0, 5 },
  },
  useLvgl = true,
}
